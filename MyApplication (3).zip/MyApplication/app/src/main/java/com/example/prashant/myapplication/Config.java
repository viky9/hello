package com.example.prashant.myapplication;

import android.graphics.Bitmap;

/**
 * Created by prashant on 21-08-2017.
 */

public class Config {
//    public static final String DATA_URL = "http://192.168.42.166/FcmExample/GetRegisterdDevices.php";
//    public static final String KEY_NAME = "id";
//    public static final String KEY_ADDRESS = "email";
//    public static final String KEY_VC = "token";
//    public static final String JSON_ARRAY = "devices";

        public static String[] names;
        public static String[] urls;
       // public static Bitmap[] bitmaps;

        public static final String GET_URL = "http://192.168.42.166/FcmExample/GetDevices.php";
        public static final String TAG_IMAGE_URL = "url";
        public static final String TAG_IMAGE_NAME = "name";
        public static final String TAG_JSON_ARRAY="result";

        public Config(int i){
            names = new String[i];
            urls = new String[i];
          //  bitmaps = new Bitmap[i];
        }
    }