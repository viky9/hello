package com.example.prashant.myapplication;

import android.graphics.Bitmap;

/**
 * Created by prashant on 21-08-2017.
 */

public class Config {
//    public static final String DATA_URL = "http://192.168.42.166/FcmExample/GetRegisterdDevices.php";
//    public static final String KEY_NAME = "id";
//    public static final String KEY_ADDRESS = "email";
//    public static final String KEY_VC = "token";
//    public static final String JSON_ARRAY = "devices";

    public static String[] ids;
    public static String[] emails;
    public static String[] tokens;

    public static final String GET_URL = "http://192.168.42.166/FcmExample/RegisterDevice.php;";
    public static final String TAG_ID = "id";
    public static final String TAG_email = "email";
    public static final String TAG_token = "token";

    public static final String TAG_JSON_ARRAY="devices";

    public Config(int i){
        ids = new String[i];
        emails = new String[i];
        tokens = new String[i];
    }
}
