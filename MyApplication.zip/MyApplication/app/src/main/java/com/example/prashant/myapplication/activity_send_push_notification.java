package com.example.prashant.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class activity_send_push_notification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_push_notification);
    }
}
