package com.example.prashant.myapplication;

/**
 * Created by prashant on 17-08-2017.
 */

public class EndPoints {
    public static final String URL_REGISTER_DEVICE = "http://192.168.1.102/FcmExample/RegisterDevice.php";
    public static final String URL_SEND_SINGLE_PUSH = "http://192.168.1.102/FcmExample/sendSinglePush.php";
    public static final String URL_SEND_MULTIPLE_PUSH = "http://192.168.1.102/FcmExample/sendMultiplePush.php";
    public static final String URL_FETCH_DEVICES = "http://192.168.1.102/FcmExample/GetRegisteredDevices.php";
}