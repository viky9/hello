<?php 
 define('DB_USERNAME','root');
 define('DB_PASSWORD','');
 define('DB_NAME','fcm');
 define('DB_HOST','localhost');

  //defined a new constant for firebase api key
 define('FIREBASE_API_KEY', 'AIzaSyBFfq7m-2wUMW2CuSW_2pjTFNK8GgAnIzg');
